# Arkenfox config install for journalists
```
install_journoSEC_config/
├── install_journoSEC_config/
│   ├── __init__.py
│   ├── __main__.py
│   └── move_user_js.py
├── user.js
├── user-overrides.js
├── setup.py
└── MANIFEST.in
```
