"""A package for installing JournoSec Firefox configuration files."""

__version__ = '1.0'

from .move_user_js import get_username, move_user_js
